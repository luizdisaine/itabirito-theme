<?php 
    /**
     * Template Name: Descubra Itabirito
     * 
     * @package Itabirito
     */
    
    if (wp_is_mobile()) {
        get_header('mobile');
    } else {
        get_header();
    }

    global $post;
    
    $children = get_pages( array( 'child_of' => $post->ID, 'hierarchical' => 1, 'sort_order' => 'desc' ) ); 
    
    if( count( $children ) == 0 ) { ?>

<div class="container main" id="conteudo">
    <div class="row">
        <?php if (!wp_is_mobile()) { ?>
        <div class="col-lg-3 left-col">
            <?php thesidebar(); ?>
        </div>
        <?php } ?>
        <div class="col-lg-9 ms-auto">
            <?php 
                if (have_posts()) {
                    while (have_posts()) { the_post();
                    get_template_part( 'assets/contents/content-page' );
                }
            }
            ?>
        </div>
        <?php if (wp_is_mobile()) { ?>
        <div class="col-lg-3 left-col">
            <?php
                thesidebar();
            ?>
        </div>
        <?php } ?>
    </div>
</div>

<?php } else { 
    
    ?>

<div class="container-fluid py-5 parent-menu bg-amarelo">
    <div class="container">
        <div class="row menu-parent">
            <?php               
                if (is_active_sidebar('turismo')) { 
                    echo '<div class="col-lg-6">';
                    do_action('before_sidebar');
                    dynamic_sidebar('turismo');
                    echo '</div>';
                echo '<div class="col-lg-6">';
                } else {
                    echo '<div class="col-lg-12">';
                }
                ?>
            <?php wp_nav_menu(
                        array(
                            'depth' => '1',
                            'theme_location' => 'turismo', 
                            'container' => false, 
                            'menu_class' => 'me-auto'
                            )
                        );
                    if (!wp_is_mobile()) {
                        echo '<ul class="menu-children text-end">';
                        the_content();                
                     
                        wp_list_pages( array(
                            'child_of' => $post->ID, // Only pages that are children of the current page
                            'depth' => 1 ,   // Only show one level of hierarchy
                            'sort_column' => 'post_title',
                            'sort_order' => 'ASC',
                            'title_li'    => ''
                        ));
                        echo '</ul>';
                    } ?>

        </div>
    </div>
</div>
</div>
<?php if (!wp_is_mobile()) { ?>
<!--div class="container-fluid" id="servicos">
    <div class="row">
        <div class="col-lg-12">
            <h3>Como podemos ajudar?<span>Menu de serviços</span></h3>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php //get_template_part( 'assets/nav/nav_servicos' ) ?>
            </div>
        </div>
    </div>
</!--div -->

<?php }}
?>
        
<?php if (!wp_is_mobile()) { get_footer(); } else {get_footer('mobile'); } ?>