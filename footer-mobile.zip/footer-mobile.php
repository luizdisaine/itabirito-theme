

<div class="container-fluid" id="survey">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 mx-auto">
                <?php if (!is_front_page()) {
                    echo do_shortcode( '[wpforms id="85144"]' ); 
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php 

if (is_page('descubra-itabirito')) {
    echo '<div class="d-flex w-100 position-absolute bottom-0 bg-dark py-1" style="display: none" id="check-pwa"><button id="install-app-button" type="button" class="btn btn-primary btn-sm m-auto">Instalar como app na tela inicial</button></div>'; ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        window.AddToHomeScreenInstance = window.AddToHomeScreen({
            appName: 'Descubra Itabirito', // Name of the app.
            // Required.
            appNameDisplay: 'fullscreen', // If set to 'standalone' (the default), the app name will be diplayed
            // on it's own, beneath the "Install App" header. If set to 'inline', the
            // app name will be displayed on a single line like "Install MyApp"
            // Optional. Default 'standalone'
            appIconUrl: 'https://itabirito.mg.gov.br/wp-content/uploads/2026/01/descubra-itabirito.png', // App icon link (square, at least 40 x 40 pixels).
            // Required.
            assetUrl: 'https://cdn.jsdelivr.net/gh/philfung/add-to-homescreen@3.5/dist/assets/img/', // Link to directory of library image assets.

            maxModalDisplayCount: 1, // If set, the modal will only show this many times.
            // [Optional] Default: -1 (no limit).  (Debugging: Use this.clearModalDisplayCount() to reset the count)
            displayOptions: {
                showMobile: true,
                showDesktop: false
            }, // show on mobile/desktop [Optional] Default: show everywhere
            allowClose: true, // allow the user to close the modal by tapping outside of it [Optional. Default: false]
            showArrow: true, // show the bouncing arrow on the modal [Optional. Default: true] (highly recommend leaving at true as drastically affects install rates)
        });

        ret = window.AddToHomeScreenInstance.show(
        'pt'); // show "add-to-homescreen" instructions to user, or do nothing if already added to homescreen
        // [optional] language.  If left blank, then language is auto-decided from (1) URL param locale='..' (e.g. /?locale=es) (2) Browser language settings
        
        // Add button click handler to show modal
        const installButton = document.getElementById('install-app-button');
        if (installButton) {
            installButton.addEventListener('click', function(e) {
                e.preventDefault();
                if (window.AddToHomeScreenInstance) {
                    window.AddToHomeScreenInstance.clearModalDisplayCount();
                    window.AddToHomeScreenInstance.show('pt');
                }
            });
        }
        // Check if the app is running in standalone mode (installed)
        const isInstalled = window.matchMedia('(display-mode: standalone)').matches;
        
        if (isInstalled) {
        console.log("PWA is already installed!");
        // Hide A2HS button
        } else {
        console.log("PWA not installed.");
        // Show A2HS button
        document.getElementById('check-pwa').style.display = 'block';
        }
    });
</script>
<?php }
?>

<footer class="container-fluid py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                <?php get_template_part( 'assets/nav/nav_social' ); ?>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-6"><a href="<?php bloginfo( 'url' )?>" alt="<?php bloginfo('name'); ?>"><img src="<?php echo get_template_directory_uri().'/img/logo-footer.png'; ?>" width="160"></a></div>
                <div class="col-lg-6">
                    <span class="copyright">&copy; 2019 – <?php echo date('Y'); ?>. Todos os direitos reservados.</span>
                </div>
            </div>
        </div>
    </footer>

    <?php wp_footer(); ?>
    <script>
    
    const banner = document.querySelector('#bannerslider');
    const carousel2 = new bootstrap.Carousel(banner, {
        ride: "carousel",
        interval: 5000,
    })

    jQuery(document).ready(function () {
        jQuery(".owl-carousel").owlCarousel({
            loop: true,
            margin: 30,
            nav: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 6000,
            autoplayHoverPause: true,
            responsiveClass: true,
            responsive: {
                360: {
                    items: 1,
                    nav: false
                },
                600: {
                    items: 1,
                    nav: false
                }
            }
        });
    });
</script>
</body>
</html>